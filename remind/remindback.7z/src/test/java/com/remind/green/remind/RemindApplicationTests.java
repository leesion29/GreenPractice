package com.remind.green.remind;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RemindApplicationTests {

	@Test
	void contextLoads() {
	}

}
