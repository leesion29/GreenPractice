import { Link, Outlet } from "react-router-dom";

function App() {
  return (
    <>
      <nav>
        <Link to="/">홈</Link> | <Link to="/about">소개</Link>
      </nav>
      <Outlet /> {/* 자식 컴포넌트가 여기에 렌더링됨 */}
    </>
  );
}

export default App;
