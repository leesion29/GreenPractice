import "./App.css";
import A from "./components/menus/todo/A";

function App() {
  return <div>
    <A />
  </div>
}

export default App;
