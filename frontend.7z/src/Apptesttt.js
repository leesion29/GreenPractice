import {RouterProvider} from "react-router-dom";
import root from "./router/root";
import Prj from "./components/Prj";

function App() {
  return (
    <Prj v = "사랑"/>
  );
}

export default App;

