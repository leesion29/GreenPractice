// import React from 'react'
// import B from "./B"
// const A = () => {
//   const f = (v) => {
//     var sum1 = 0;
//     for(i of v) {
//       sum1 += i;
//     }
//   }

//   const f2 = (v2) => { 
//     let sum = 0;
//     //console.log(Object.keys(v2.a.b).length) -> 7 (파라미터로 입력받은 객체의 key 목록을 배열로 리턴)
//     for(let i = 0; i<7; i++){
//       sum += v2.a.b[i]
//     }
//     return sum;
//   }

//   return (
//     <div>A
//       <B a="홍길동" b="김개똥" c={f} d={f2}></B>
//     </div>
//   )
// }

// export default A