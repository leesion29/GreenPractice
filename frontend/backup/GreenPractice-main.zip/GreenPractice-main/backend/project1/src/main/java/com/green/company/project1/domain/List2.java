package com.green.company.project1.domain;

public class List2 {
}
