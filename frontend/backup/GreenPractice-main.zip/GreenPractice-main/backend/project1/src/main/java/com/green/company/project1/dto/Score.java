package com.green.company.project1.dto;

@FunctionalInterface
public interface Score {
    public void run();
    //public void drive();
}
