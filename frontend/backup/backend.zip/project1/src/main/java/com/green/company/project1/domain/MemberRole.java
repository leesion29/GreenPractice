package com.green.company.project1.domain;

public enum MemberRole {
    USER, MANAGER, ADMIN; // 0 일반 1 관리자 2 특급, 어드민
}
