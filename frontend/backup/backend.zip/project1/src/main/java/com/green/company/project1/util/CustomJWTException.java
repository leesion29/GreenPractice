package com.green.company.project1.util;

public class CustomJWTException extends RuntimeException{
    public CustomJWTException(String msg) {
        super(msg);
    }
}
