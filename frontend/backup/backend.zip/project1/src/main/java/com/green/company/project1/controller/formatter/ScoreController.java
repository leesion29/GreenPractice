package com.green.company.project1.controller.formatter;
//@RequiredArgsConstructor
//@RestController
//@Log4j2
//@RequestMapping("/api/score")
//public class ScoreController {
//    private final ScoreService service;
//
//    @GetMapping("/{sno}")
//    public ScoreDTO get(@PathVariable(name = "sno") Long sno) {
//        return service.get(sno);
//    }
//
//    @GetMapping("/list")
//    public PageResponseDTO<ScoreDTO> list(PageRequestDTO pageRequestDTO) {
//
//        return service.post(sno);
//    }
//    @GetMapping("/read")
//    @GetMapping("/modify")
//}
