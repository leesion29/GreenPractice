package com.green.company.project1.dto;

@FunctionalInterface
public interface Magic {
    public int tt(int a, int b);
}
