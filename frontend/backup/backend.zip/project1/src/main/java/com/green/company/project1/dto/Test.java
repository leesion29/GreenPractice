package com.green.company.project1.dto;

public class Test {
    public static void main(String[] args) {
//        Score a = new Score() {
//            @Override
//            public void run() {
//                System.out.println("사랑");
//            }
//        };
//        a.run();
//        a = () -> System.out.println("행복");
//        a.run();
//
//        //ans> 함수형 인터페이스를 만든다.
//        Magic m = new Magic(){
//
//            @Override
//            public int tt(int a, int b){
//                return a + b;
//            }
//        };
//        m.tt(1,2);
//
//        Function<Integer, Integer> fn = (Integer t) -> t*2;
//        int v = fn.apply(11);
//        System.out.println(v);
//        Function <Integer, ProductDTO> fn2 = (u) -> {
//            return new ProductDTO().builder()
//                    .pno(11l)
//                    .price(34000)
//                    .pname("사랑합니다.")
//                    .pdesc("행복합니다")
//                    .build();
//        };
//        ProductDTO vvv = fn2.apply(11);
//        System.out.println(vvv);
//        Predicate<Integer> p1 = (i) -> i%2 == 0;
//        boolean uuuu = p1.test(11);
//        System.out.println(uuuu);
//        List<ProductDTO> list = IntStream.rangeClosed(1, 100).filter(i->i%2==0)
//                .mapToObj(i->{
//                    return new ProductDTO().builder()
//                            .pno(11l)
//                            .price(34000)
//                            .pname("사랑합니다.")
//                            .pdesc("행복합니다")
//                            .build();
//                }).collect(Collectors.toList());
//        System.out.println(list);
//        System.out.println("=======================");
//        List<String> myList = new ArrayList<>();
//        myList.add("삼양라면");
//        myList.add("신라면");
//        myList.add("비빔면");
//        myList.add("진라면");
//
//        // 1.
//        Consumer<String> RamenData = i ->
//                System.out.println("라면 데이터 : " + i);
//        myList.forEach(RamenData);
//
//        // 2.
//        myList.forEach(i -> System.out.println("간략화 된 라면 데이터 : " + i));
        System.out.printf("");
    }

}
