// import React from 'react'

// const B = (a) => {
//     // console.log(a)
//     // console.log(a.c[1,2,3,4,5])
//     console.log(a.d({a:{
//       "b" : [1,2,3,4,5,6,11]
//     }}));
//   return <div>B</div>
// }

// export default B